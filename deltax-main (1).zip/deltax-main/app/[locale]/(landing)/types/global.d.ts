interface Window {
    tolt_referral?: string;
} 