import { UserEquityGridClient } from "./user-equity-grid-client";

export async function UserEquityDashboard() {
  return (
    <div className="p-6 space-y-6">
    <UserEquityGridClient 
    />
    </div>
  )
} 