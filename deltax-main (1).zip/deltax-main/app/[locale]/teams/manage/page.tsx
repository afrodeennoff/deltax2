'use client'

import { TeamManagement } from "@/app/[locale]/teams/components/team-management"

export default function TeamManagePage() {

  return (
    <TeamManagement
    />
  )
}
